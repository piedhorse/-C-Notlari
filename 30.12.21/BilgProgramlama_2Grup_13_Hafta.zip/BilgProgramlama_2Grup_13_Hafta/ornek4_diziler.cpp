/* Bir dizinin eleman say�s�n�(uzunluk) bulma */
#include<iostream>
using namespace std;
int main()
{
	int notlar[]={25,36,48,78,58,69,41,45,78,95,68,25,36,45,78,25,14,56,78,59,45,55,69};
 	
 	double fiyatlar[5];
 	fiyatlar[0] = 75.30;
 	fiyatlar[1] = 105.99;
 	fiyatlar[2] = 49.99;
 	fiyatlar[3] = 30.50;
 	fiyatlar[4] = 10.00;
 	
 	int uzunluk;
 	uzunluk = sizeof(notlar)/sizeof(int); 	
 	for(int i=0; i<uzunluk; i++)
 	{
 	   cout<<notlar[i]<<"-";	
	}
	 
	cout<<endl;
	
	uzunluk = sizeof(fiyatlar)/sizeof(double);	
	for(int i=0; i<uzunluk; i++)
	{
	   cout<<i+1<<".fiyat="<<fiyatlar[i]<<endl;	
	} 
	
 	
	return 0;
}
