/* 5 elemanl� bir int dizisi tan�mland� ve elamanlar� ekrana yazd�r�ld� */
#include<iostream>
using namespace std;
int main()
{
	int a[5]={15,25,35,45,69};
	
	for(int i=0; i<5; i++)
	{
		cout<<a[i]<<endl;
		//cout<<"Dizinin "<<i+1<<".elemani ="<<a[i]<<endl;		
	}
	
	return 0;
}
