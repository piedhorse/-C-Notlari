/* 5 elemanl� bir double dizisi tan�mland� ve elamanlar� ekrana yazd�r�ld� */
#include<iostream>
using namespace std;
int main()
{
	double b[5];
	
	b[0] = 2.25;
	b[1] = 1.45;
	b[2] = 2.77;
	b[3] = 4.45;
	b[4] = 7.85;
 	
 	for(int i=0; i<5; i++)
 	{
 		cout<<b[i]<<endl;
	 }
 	
 	
	return 0;
}
