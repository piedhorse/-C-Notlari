/* Bir diziye konsoldan veri girme ve girilen verilerin ortalamas�n� bulma*/
#include<iostream>
using namespace std;
int main()
{
	int n;          //n = elaman say�s�
	int toplam=0;
	double ort;
	
	cout<<"Kac adet not girilecek:";
	cin>>n;
	
	int notlar[n];
  		
 	for(int i=0; i<n; i++)
 	{
 		cout<<i+1<<".notu giriniz:";
 		cin>>notlar[i];
 		toplam += notlar[i]; 		
	}
	 
	cout<<endl;
	ort = (double)toplam / (double)n;    
	cout<<"Girilen notlarin ortalamasi="<<ort;
 	
	return 0;
}
