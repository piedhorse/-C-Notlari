/* Bir dizinin eleman say�s�n�(uzunluk) bulma */
#include<iostream>
using namespace std;
int main()
{
	int notlar[]={25,36,48,78,58,69,41,45,78,95,68,25,36,45,78,25,14,56,78,59,45};
 	
 	int uzunluk;
 	uzunluk = sizeof(notlar)/sizeof(int);
	 	 
	cout<<"Dizinin eleman sayisi:"<<uzunluk<<endl;	
 	
	return 0;
}
