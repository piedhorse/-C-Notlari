/* Bir diziye konsoldan veri girme*/
#include<iostream>
using namespace std;
int main()
{
	int uzunluk;
	
	cout<<"Kac adet not girilecek:";
	cin>>uzunluk;
	
	int notlar[uzunluk];
  		
 	for(int i=0; i<uzunluk; i++)
 	{
 		cout<<i+1<<".notu giriniz:";
 		cin>>notlar[i];
	}
	 
	cout<<endl;
	
	for(int i=0; i<uzunluk; i++)
 	{
 		cout<<i+1<<".not:"<<notlar[i]<<"\n"; 		
	}
	
 	
	return 0;
}
